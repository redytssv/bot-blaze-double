
echo "oi"
node index.js 
sleep 1      
done
